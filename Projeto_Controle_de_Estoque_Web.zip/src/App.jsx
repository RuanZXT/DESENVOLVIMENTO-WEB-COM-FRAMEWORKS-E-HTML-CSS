import React, { useEffect, useMemo, useState } from 'react';
import { Package, Plus, Search, TrendingUp, TrendingDown, AlertTriangle, Boxes, Trash2, Pencil, X, FileDown, RotateCcw } from 'lucide-react';

const initial = [
  { id: 1, name: 'Caderno universitário', code: 'CAD-001', category: 'Papelaria', quantity: 24, minimum: 10, price: 18.90 },
  { id: 2, name: 'Caneta azul', code: 'CAN-002', category: 'Papelaria', quantity: 8, minimum: 15, price: 2.50 },
  { id: 3, name: 'Copo térmico', code: 'COP-003', category: 'Utilidades', quantity: 12, minimum: 5, price: 34.90 }
];
const money = n => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export default function App() {
  const [products, setProducts] = useState(() => {
    try { return JSON.parse(localStorage.getItem('estoque-produtos')) || initial; } catch { return initial; }
  });
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('todos');
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [movement, setMovement] = useState(null);
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({ name:'', code:'', category:'Geral', quantity:0, minimum:1, price:0 });
  useEffect(() => localStorage.setItem('estoque-produtos', JSON.stringify(products)), [products]);

  const low = products.filter(p => Number(p.quantity) <= Number(p.minimum));
  const totalUnits = products.reduce((s,p) => s + Number(p.quantity), 0);
  const totalValue = products.reduce((s,p) => s + Number(p.quantity)*Number(p.price), 0);
  const visible = useMemo(() => products.filter(p => {
    const q = `${p.name} ${p.code} ${p.category}`.toLowerCase().includes(search.toLowerCase());
    return q && (filter === 'todos' || (filter === 'baixo' ? Number(p.quantity) <= Number(p.minimum) : Number(p.quantity) > Number(p.minimum)));
  }), [products, search, filter]);

  function openNew() { setEditing(null); setForm({ name:'', code:'', category:'Geral', quantity:0, minimum:1, price:0 }); setModal(true); }
  function openEdit(p) { setEditing(p.id); setForm({ ...p }); setModal(true); }
  function save(e) {
    e.preventDefault();
    if (!form.name.trim() || !form.code.trim()) return;
    const clean = { ...form, quantity:Number(form.quantity), minimum:Number(form.minimum), price:Number(form.price) };
    setProducts(old => editing ? old.map(p => p.id === editing ? { ...clean, id:editing } : p) : [...old, { ...clean, id:Date.now() }]);
    setModal(false); setNotice(editing ? 'Produto atualizado.' : 'Produto cadastrado.');
  }
  function adjust(p, type) {
    const amount = Number(prompt(type === 'entrada' ? `Quantidade que entrou em ${p.name}:` : `Quantidade que saiu de ${p.name}:`, '1'));
    if (!Number.isFinite(amount) || amount <= 0) return;
    if (type === 'saida' && amount > p.quantity) { setNotice('A saída não pode ser maior que o estoque disponível.'); return; }
    setProducts(old => old.map(x => x.id === p.id ? { ...x, quantity:x.quantity + (type === 'entrada' ? amount : -amount) } : x));
    setNotice(`${type === 'entrada' ? 'Entrada' : 'Saída'} registrada com sucesso.`);
  }
  function remove(p) {
    if (confirm(`Excluir o produto "${p.name}"?`)) setProducts(old => old.filter(x => x.id !== p.id));
  }
  function reset() {
    if (confirm('Restaurar os produtos de demonstração? Os dados atuais serão substituídos.')) { setProducts(initial); setNotice('Dados de demonstração restaurados.'); }
  }

  return <main className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" aria-label="Estoque Fácil - página inicial"><span className="brand-icon"><Package size={22}/></span><span>Estoque<span className="brand-light">Fácil</span><small>GESTÃO SIMPLES DO SEU NEGÓCIO</small></span></a>
      <div className="top-actions"><span className="status"><i/> Dados salvos neste dispositivo</span><button className="btn btn-light" onClick={reset} title="Restaurar demonstração"><RotateCcw size={16}/> Restaurar</button></div>
    </header>

    <section className="intro">
      <div><p className="eyebrow">PAINEL DE CONTROLE</p><h1>Visão geral do estoque</h1><p className="sub">Acompanhe seus produtos, movimentações e níveis de estoque.</p></div>
      <button className="btn btn-primary" onClick={openNew}><Plus size={18}/> Novo produto</button>
    </section>

    {notice && <div className="notice" role="status">{notice}<button aria-label="Fechar aviso" onClick={() => setNotice('')}><X size={15}/></button></div>}

    <section className="stats" aria-label="Resumo do estoque">
      <article className="stat-card"><div className="stat-icon blue"><Boxes/></div><div><p>Produtos cadastrados</p><strong>{products.length}</strong><small>itens diferentes</small></div></article>
      <article className="stat-card"><div className="stat-icon violet"><Package/></div><div><p>Unidades em estoque</p><strong>{totalUnits}</strong><small>unidades disponíveis</small></div></article>
      <article className="stat-card"><div className="stat-icon green"><TrendingUp/></div><div><p>Valor estimado</p><strong>{money(totalValue)}</strong><small>com base no preço cadastrado</small></div></article>
      <article className="stat-card"><div className="stat-icon orange"><AlertTriangle/></div><div><p>Estoque baixo</p><strong>{low.length}</strong><small>produtos no limite ou abaixo</small></div></article>
    </section>

    <section className="panel">
      <div className="panel-heading"><div><h2>Produtos</h2><p>Consulte e atualize os itens cadastrados.</p></div><button className="btn btn-outline" onClick={() => window.print()}><FileDown size={16}/> Imprimir relatório</button></div>
      <div className="toolbar">
        <label className="search"><Search size={18}/><span className="sr-only">Buscar produtos</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nome, código ou categoria..."/></label>
        <label className="filter-label">Exibir <select value={filter} onChange={e => setFilter(e.target.value)}><option value="todos">Todos</option><option value="baixo">Estoque baixo</option><option value="normal">Estoque normal</option></select></label>
      </div>
      <div className="table-wrap"><table><thead><tr><th>Produto</th><th>Categoria</th><th>Quantidade</th><th>Estoque mínimo</th><th>Preço unitário</th><th>Situação</th><th><span className="sr-only">Ações</span></th></tr></thead>
      <tbody>{visible.map(p => <tr key={p.id}><td><strong>{p.name}</strong><small className="code">{p.code}</small></td><td>{p.category}</td><td><strong>{p.quantity}</strong></td><td>{p.minimum}</td><td>{money(p.price)}</td><td>{p.quantity <= p.minimum ? <span className="pill warning">Estoque baixo</span> : <span className="pill success">Normal</span>}</td><td><div className="row-actions"><button title="Registrar entrada" aria-label={`Registrar entrada de ${p.name}`} onClick={() => adjust(p,'entrada')}><TrendingUp size={16}/></button><button title="Registrar saída" aria-label={`Registrar saída de ${p.name}`} onClick={() => adjust(p,'saida')}><TrendingDown size={16}/></button><button title="Editar" aria-label={`Editar ${p.name}`} onClick={() => openEdit(p)}><Pencil size={16}/></button><button title="Excluir" aria-label={`Excluir ${p.name}`} onClick={() => remove(p)}><Trash2 size={16}/></button></div></td></tr>)}
      {visible.length === 0 && <tr><td colSpan="7" className="empty">Nenhum produto encontrado para esta busca.</td></tr>}</tbody></table></div>
      <div className="table-footer"><span>Exibindo {visible.length} de {products.length} produtos</span><span>Os dados ficam armazenados no navegador.</span></div>
    </section>
    <footer>Estoque Fácil · Projeto acadêmico demonstrativo · <span>Controle simples para pequenos negócios</span></footer>

    {modal && <div className="modal-backdrop" role="presentation" onMouseDown={e => e.target === e.currentTarget && setModal(false)}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div className="modal-head"><div><h2 id="modal-title">{editing ? 'Editar produto' : 'Cadastrar produto'}</h2><p>Preencha os dados para manter o estoque atualizado.</p></div><button className="close" onClick={() => setModal(false)} aria-label="Fechar"><X/></button></div>
      <form onSubmit={save}><label>Nome do produto<input required value={form.name} onChange={e => setForm({...form,name:e.target.value})} placeholder="Ex.: Arroz 5 kg"/></label><div className="form-grid"><label>Código<input required value={form.code} onChange={e => setForm({...form,code:e.target.value})} placeholder="Ex.: ARR-001"/></label><label>Categoria<input value={form.category} onChange={e => setForm({...form,category:e.target.value})}/></label><label>Quantidade<input type="number" min="0" required value={form.quantity} onChange={e => setForm({...form,quantity:e.target.value})}/></label><label>Estoque mínimo<input type="number" min="0" required value={form.minimum} onChange={e => setForm({...form,minimum:e.target.value})}/></label><label className="full">Preço unitário (R$)<input type="number" min="0" step="0.01" required value={form.price} onChange={e => setForm({...form,price:e.target.value})}/></label></div><div className="modal-actions"><button type="button" className="btn btn-light" onClick={() => setModal(false)}>Cancelar</button><button type="submit" className="btn btn-primary">Salvar produto</button></div></form>
    </section></div>}
  </main>;
}