# Estoque Fácil — Controle de Estoque

Aplicação web demonstrativa para pequenos comércios e microempreendedores.

## Funcionalidades
- Cadastro, edição e exclusão de produtos.
- Registro de entrada e saída de unidades.
- Busca por nome, código ou categoria.
- Filtro de produtos com estoque baixo ou normal.
- Indicadores de quantidade e valor estimado do estoque.
- Impressão da listagem pelo navegador.
- Persistência dos dados no `localStorage`.

## Tecnologias
- React 18: construção da interface em componentes.
- Vite: ambiente de desenvolvimento e geração da versão de produção.
- HTML5 semântico e CSS3 responsivo.
- Lucide React: ícones da interface.

## Requisitos
Node.js 18 ou superior e npm.

## Instalação e execução
```bash
npm install
npm run dev
```
Abra no navegador o endereço local exibido pelo Vite.

## Gerar versão de produção
```bash
npm run build
npm run preview
```
Os arquivos finais serão gerados na pasta `dist/`.

## Observações
Este é um protótipo acadêmico. Os dados são armazenados localmente no navegador e não são sincronizados entre dispositivos. Para uso comercial real, recomenda-se adicionar backend, banco de dados, autenticação, controle de permissões, cópias de segurança e histórico persistente de movimentações.

## Acessibilidade e responsividade
A interface utiliza idioma `pt-BR`, títulos hierárquicos, rótulos associados aos campos, tabela com cabeçalhos, textos alternativos para controles, regiões de status e estilos adaptados para telas menores e impressão.
